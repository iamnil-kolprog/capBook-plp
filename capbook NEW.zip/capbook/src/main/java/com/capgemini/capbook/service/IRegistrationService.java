package com.capgemini.capbook.service;

import java.util.List;
import java.util.Optional;

import com.capgemini.capbook.exceptions.UserException;
import com.capgemini.capbook.model.Registration;

public interface IRegistrationService {
	
	 public List<Registration> getAllRegistrations();
	 public Optional<Registration> getRegistration(String id);
	 public void addRegistration(Registration registration);
	 public Registration getUser(String email,String password) throws UserException;

	 public Registration getUser1(String email,String answer) throws UserException;
	 public void changePass(String email,Registration oldPass,  String newPass) throws UserException;
	 public void forgotPass1(String email,Registration oldPass,  String newPass);
	 public List<Registration> getAll(String email);
}
