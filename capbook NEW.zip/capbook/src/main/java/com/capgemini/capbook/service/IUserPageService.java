package com.capgemini.capbook.service;

import java.util.List;

import com.capgemini.capbook.model.CapComments;
import com.capgemini.capbook.model.HomePage;
import com.capgemini.capbook.model.PictureStatus;
import com.capgemini.capbook.model.ProfilePicture;

public interface IUserPageService {
	
	public List<ProfilePicture> getProfile();
	public void addProfile(ProfilePicture profile);
	public void update(ProfilePicture profile);
	public List<HomePage> getAllStatusInText();
	public void postStatusInText(HomePage hp);
	public void removeStatus(int id);
	public List<PictureStatus> getPictures();
	public void addPic(PictureStatus pictures);
	public void deletePicture(int id);
	public List<CapComments> getAllCommentInText();
	public void postCommentInText(CapComments hp);
	public List<CapComments> getCapComments();
	public List<String> search(String name);

}
