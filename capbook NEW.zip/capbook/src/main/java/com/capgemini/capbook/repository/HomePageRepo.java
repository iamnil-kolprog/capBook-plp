package com.capgemini.capbook.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.capbook.model.HomePage;

public interface HomePageRepo extends CrudRepository<HomePage,Integer> {

}
