package com.capgemini.capbook.service;

import java.util.HashSet;
import java.util.List;

import com.capgemini.capbook.model.FriendRequest;

public interface IFriendRequestService {
	public void saveRequest(FriendRequest friendReq);
	public List<String> getAllRequest(String toName);
	public void remove(String fromName, String toNam);
	public void acceptReq(String fromName, FriendRequest friendReq);
	public HashSet<String> getFriendList(String name);
	public boolean check(String email1,String email2);

}
